<template>
	<view></view>
</template>