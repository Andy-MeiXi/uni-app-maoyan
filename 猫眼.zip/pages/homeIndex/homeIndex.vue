<template>
	<view>
		<view class="navbar">
			<u-navbar  
				title="猫眼电影" 
				title-size="36"
				title-color="#fff" 
				:background="background"
				:is-back="false"
				height="50"
			>
				<u-icon 
					name="list" size="46" 
					color="#fff"
					class="navIcon"
				>
				</u-icon>
			</u-navbar>
		</view>
		
		<view class="navCenter">
			<view class="navCenterflex">
				<image 
					class="navImage"
					src="../../static/image/maoyanLogo.png"
					mode="aspectFill">
				</image>
				<view class="navCenterflexRight">
					<view class="navFaxian">发现最新最热电影</view>
					<view class="navApp">打开App ></view>
				</view>
			</view>
		</view>
		
		<!-- 标题 -->
		<view class="filmType">
			<view class="filmTypeItem">
				<view class="filmAdd">徐州</view>
				<!-- :class="{filmTypeMsgAfter:item.id == typeId}" -->
				<view :class="item.id == typeId ? 'filmTypeMsgAfter': 'filmTypeMsg'"
					@click="clickType(item.id)"
					v-for="(item,index) in titleType"
					:key="item.id"
				>
				{{item.title}}
				</view>
				<u-icon name="search"
					color="#e54847" size="36"></u-icon>
			</view>
		</view>
		
		<!-- 热映页面 -->
		<!-- 好评电影 -->
		<view class="reying" v-if="typeId == 1">
			<view class="goodFilm">
				<view class="goodTitle">最受好评电影</view>
				<scroll-view scroll-x="true" class="goodScorllView">
					<view class="gootItem" @click="gotoFilmPage">
						<view class="gootItemMsg"
							v-for="(item,index) in gootfilmlist"
							:key="item.id"
						>
							<image class="gootImage"
							 :src="item.image"></image>
							 <view class="goodFen">{{item.score}}</view>
							<view class="gootName">{{item.filmName}}</view>
						</view>
					</view>
				</scroll-view>
			</view>
			
			<view class="kongDiv">
			</view>
			
			<!-- 推荐电影 -->
			<view class="pushFilm">
				<view class="pushFileItem"
					@click="gotoFilmPage"
					v-for="(item,index) in filmlist"
					:key="item.id">
					<image class="pushFilmImage" :src="item.image" mode="aspectFill"></image>
					<view class="pushFilmRight">
						<view style="display: flex; align-items: center;">
							<view class="pushFilmName">{{item.fileName}}</view>
							<image class="pushD" :src="item.d"
							mode="aspectFill"></image>
						</view>
						<view class="pushCentent">
							<view class="pushFen" v-if="item.score != ''">
								<view>观众评 </view>
								<view class="pushFilmMsg">{{item.score}}</view>
							</view>
							<view v-else>
								<view>暂无评论</view>
							</view>
						</view>
						<view class="pushActor">{{item.actor}}</view>
						<view class="pushNum">{{item.content}}</view>
					</view>
					<view class="buyPushFilm">购票</view>
				</view>
			</view>
			
			<view class="kongDiv">
			</view>
			
			<!-- 热门影人 -->
			<view class="goodFilm">
				<view class="goodTitle">热门影人</view>
				<scroll-view scroll-x="true" class="goodScorllView">
					<view class="gootItem">
						<view class="gootItemMsg"
							v-for="(item,index) in actorlist"
							:key="item.id"
						>
							<image class="gootImage"
							 :src="item.image"></image>
							<view class="gootName">{{item.name}}</view>
						</view>
					</view>
				</scroll-view>
			</view>
			
			<view class="kongDiv">
			</view>
			
			<!-- 娱乐热点 -->
			<view class="recreation">
				<view class="recreationTitle">娱乐热点</view>
				<view 
					class="recreationCentent"
					v-for="(item,index) in reclist"
					:key="item.id">
					{{item.id}}.{{item.content}}
				</view>
			</view>
		</view>
		
		<!-- 影院页面 -->
		<view class="yingyuan" v-if="typeId == 2">
			<view class="dropDown">
				<u-dropdown active-color="#f03d37"
				ref="uDropdown" @open="open" @close="close">
				
					<u-dropdown-item v-model="value1" :title="title1" 
						:options="options1"  @change="changeOne">
					</u-dropdown-item>
					<u-dropdown-item v-model="value2" :title="title2" :options="options2" @change="changeTwo">
					</u-dropdown-item>
					<u-dropdown-item v-model="value3" :title="title3" :options="options3" @change="changeThree">
					</u-dropdown-item>
				</u-dropdown>
			</view>
			
			<!-- 影院详情 -->
			<view class="yingyuanMsg">
				<view class="yingyuanItem" @click="gotoCinema">
					<!-- 1 -->
					<view class="yingyuanName">中影华臣影城(石榴中心店)
						<text class="yingyuanPrice">19.9 </text>
						<text class="yingyuanY">元起</text>
					</view>
					<view class="yingyuanAdd">丰台区榴乡路88号院石榴中心斯坦福广场B1层</view>
					<view>
						<text class="yingyuanlan">退</text>
						<text class="yingyuanlan">改签</text>
					</view>
				</view>
				<!-- 2 -->
				<view class="yingyuanItem" @click="gotoCinema">
					<view class="yingyuanName">保利国际影城(天安门店)
						<text class="yingyuanPrice">25 </text>
						<text class="yingyuanY">元起</text>
					</view>
					<view class="yingyuanAdd">西城区煤市街廊房头条交叉口东北角北京坊东区B1-B2层</view>
					<view>
						<text class="yingyuanlan">改签</text>
						<text class="yingyuanhuang">折扣卡</text>
						<text class="yingyuanlan">杜比全景声厅</text>
						<text class="yingyuanlan">4K厅</text>
						<text class="yingyuanlan">60帧厅</text>
						<text class="yingyuanlan">巨幕厅</text>
					</view>
					<view class="yingyuanvip">
						<image class="yingyuanIcon" src="/static/image/ka.png" mode="aspectFill"></image>
						<view class="yingyuanyouhui">开卡特惠,14元起开卡</view>
					</view>
				</view>
				<!-- 3 -->
				<view class="yingyuanItem" @click="gotoCinema">
					<view class="yingyuanName">保利国际影城(北京缤纷城店)
						<text class="yingyuanPrice">39.9 </text>
						<text class="yingyuanY">元起</text>
					</view>
					<view class="yingyuanAdd">大兴区黄村镇金星西路3号院3号楼绿地缤纷城4层07商铺层</view>
					<view>
						<text class="yingyuanlan">改签</text>
						<text class="yingyuanhuang">折扣卡</text>
						<text class="yingyuanlan">4K厅</text>
						<text class="yingyuanlan">巨幕厅</text>
					</view>
					<view class="yingyuanvip">
						<image class="yingyuanIcon" src="/static/image/ka.png" mode="aspectFill"></image>
						<view class="yingyuanyouhui">开卡特惠,17.9元起开卡</view>
					</view>
				</view>
				<!-- 4 -->
				<view class="yingyuanItem" @click="gotoCinema">
					<view class="yingyuanName">大兴影剧院
						<text class="yingyuanPrice">15.9 </text>
						<text class="yingyuanY">元起</text>
					</view>
					<view class="yingyuanAdd">大兴区黄村西大街15号</view>
					<view>
						<text class="yingyuanlan">退</text>
						<text class="yingyuanlan">改签</text>
						<text class="yingyuanhuang">折扣卡</text>
					</view>
					<view class="yingyuanvip">
						<image class="yingyuanIcon" src="/static/image/ka.png" mode="aspectFill"></image>
						<view class="yingyuanyouhui">开卡特惠,14元起开卡</view>
					</view>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				typeId:1,
				background:{
					backgroundColor:'#e54847'
				},
				titleType:[
					{
						id:1,
						title:'热映'
					},{
						id:2,
						title:'影院'
					},{
						id:3,
						title:'待映'
					},{
						id:4,
						title:'经典电影'
					},
				],
				gootfilmlist:[
					{
						id:1,
						image:'/static/image/good1.jpg',
						score:'观众评分 9.1',
						filmName:'坏蛋联盟'
					},{
						id:2,
						image:'/static/image/good2.jpg',
						score:'观众评分 9',
						filmName:'精灵旅社4'
					},{
						id:3,
						image:'/static/image/good3.jpg',
						score:'观众评分 8.9',
						filmName:'唐顿庄园2'
					},{
						id:4,
						image:'/static/image/good4.jpg',
						score:'观众评分 8.8',
						filmName:'好想去你的世界爱你'
					},{
						id:5,
						image:'/static/image/good5.jpg',
						score:'观众评分 9.3',
						filmName:'神秘海域'
					},{
						id:6,
						image:'/static/image/good6.jpg',
						score:'观众评分 9.8',
						filmName:'速度与激情'
					}
				],
				filmlist:[
					{
						id:1,
						image:'/static/image/film1.jpg',
						fileName:'神奇动物:邓布利多之谜',
						score:7.9,
						actor:'主演:埃迪·雷德梅恩、裘德·洛、麦斯·米科尔森',
						content:'今天1家影院放映1场',
						d:'/static/image/2d.png'
					},
					{
						id:2,
						image:'/static/image/film2.jpg',
						fileName:'出拳吧,妈妈',
						score:8.4,
						actor:'主演:潭卓田雨,田海蓉',
						content:'今天1家影院放映1场',
						d:''
					},
					{
						id:3,
						image:'/static/image/film3.jpg',
						fileName:'长津湖之水门桥',
						score:9.6,
						actor:'主演:吴京易烊千玺朱亚文',
						content:'今天暂无场次',
						d:'/static/image/2d.png'
					},
					{
						id:4,
						image:'/static/image/film4.jpg',
						fileName:'Bolshoi芭蕾:天鹅湖',
						score:'',
						actor:'主演:奥尔加斯米尔诺娃',
						content:'今天暂无场次',
						d:''
					},
					{
						id:5,
						image:'/static/image/film5.jpg',
						fileName:'小美人鱼的奇幻冒险',
						score:'',
						actor:'主演:绒芷,段段姚津津',
						content:'今天暂无场次',
						d:'/static/image/3d.png'
					},
				],
				actorlist:[
					{
						id:1,
						image:'/static/image/actor1.jpg',
						name:'罗翔'
					},{
						id:2,
						image:'/static/image/actor2.jpg',
						name:'约翰.布莱德利'
					},{
						id:3,
						image:'/static/image/actor3.jpg',
						name:'秦昊'
					},{
						id:4,
						image:'/static/image/actor4.jpg',
						name:'任敏'
					},{
						id:5,
						image:'/static/image/actor5.jpg',
						name:'于文文'
					},{
						id:6,
						image:'/static/image/actor6.jpg',
						name:'辛云来'
					},{
						id:7,
						image:'/static/image/actor7.jpg',
						name:'吴卓羲'
					},{
						id:8,
						image:'/static/image/actor8.jpg',
						name:'任贤齐'
					},
				],
				reclist:[
					{
						id:1,
						content:'“双雷神”合体登场!《雷神4:爱与雷霆》新按时付款了多久了是打开链接发垃圾沙拉雕刻技法',
					},
					{
						id:2,
						content:'秀山河一路繁花相送影《锦绣河山> 5月22上市,秀山河一路繁花相送影《锦绣河山> 5月22上市。',
					},{
						id:3,
						content:'韩东君《梅花红桃》开机首次挑战谍战题材引期,韩东君《梅花红桃》开机首次挑战谍战题材引期。',
					},{
						id:4,
						content:'专访电影判心剑)演员吴双:有场戏记忆深，专访电影判心剑)演员吴双:有场戏记忆深',
					},{
						id:5,
						content:'上映倒计时8天!《魔法鼠乐园》 6月18全国上映,上映倒计时8天!《魔法鼠乐园》 6月18全国上映,',
					},{
						id:6,
						content:'“双雷神”合体登场!《雷神4:爱与雷霆》新按时付款了多久了是打开链接发垃圾沙拉雕刻技法',
					},{
						id:7,
						content:'秀山河一路繁花相送影《锦绣河山> 5月22上市,秀山河一路繁花相送影《锦绣河山> 5月22上市。',
					},{
						id:8,
						content:'韩东君《梅花红桃》开机首次挑战谍战题材引期,韩东君《梅花红桃》开机首次挑战谍战题材引期。',
					},{
						id:9,
						content:'专访电影判心剑)演员吴双:有场戏记忆深，专访电影判心剑)演员吴双:有场戏记忆深',
					},{
						id:10,
						content:'上映倒计时8天!《魔法鼠乐园》 6月18全国上映,上映倒计时8天!《魔法鼠乐园》 6月18全国上映,',
					},
				],
				
				title1:'全城',
				title2:'品牌',
				title3:'特色',
				value1: 1,
				value2: 1,
				value3: 1,
				options1: [{
						label: '鼓楼区',
						value: 1,
					},
					{
						label: '泉山区',
						value: 2,
					},
					{
						label: '铜山区',
						value: 3,
					},
					{
						label: '经济开发区',
						value: 4,
					},
				],
				options2: [{
						label: '万达影城',
						value: 1,
					},
					{
						label: '保利国际影城',
						value: 2,
					},
					{
						label: '大地影院',
						value: 3,
					},
					{
						label: '华联影城',
						value: 4,
					},
					{
						label: '金逸影城',
						value: 5,
					},
				],
				options3: [{
						label: 'IMAX厅',
						value: 1,
					},
					{
						label: '杜比全景声厅',
						value: 2,
					},
					{
						label: '4DX厅',
						value: 3,
					},
					{
						label: '儿童厅',
						value: 4,
					},
					{
						label: '4K厅',
						value: 5,
					},
				],
				
			}
		},
		methods: {
			clickType(id){
				this.typeId = id
			},
			gotoFilmPage(){
				uni.navigateTo({
					url:'filmPage'
				})
			},
			open(index) {
				// 展开某个下来菜单时，先关闭原来的其他菜单的高亮
				// 同时内部会自动给当前展开项进行高亮
				this.$refs.uDropdown.highlight();
			},
			close(index) {
				// 关闭的时候，给当前项加上高亮
				// 当然，您也可以通过监听dropdown-item的@change事件进行处理
				// this.$refs.uDropdown.highlight(index);
			},
			changeOne(e) {
				// 更多的细节，如有需要请自行根据业务逻辑进行处理
				// this.$refs.uDropdown.highlight(xxx);
				// console.log(e)
				// console.log(this.options1[e].label)
				this.title1 = this.options1[e].label
				
			},
			changeTwo(e){
				this.title2 = this.options2[e].label
			},
			changeThree(e){
				this.title3 = this.options3[e].label
			},
			gotoCinema(){
				uni.navigateTo({
					url:'cinemaPage'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	// page{
	// 	background-color: #fff;
	// }
	.kongDiv{
		width: 750rpx;
		height:20rpx;
		background-color: #f2f2f2;
	}
	.navIcon{
		position: fixed;
		right: 20rpx;
	}
	.navCenter{
		border-bottom: 1px solid #e7e7e7;
	}
	.navCenterflex{
		margin: 20rpx 25rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.navImage{
		width: 180rpx;
		height: 80rpx;
	}
	.navCenterflexRight{
		display: flex;
		align-items: center;
	}
	.navFaxian{
		margin-right: 20rpx;
		font-size: 28rpx;
		font-weight: bold;
		color: #66667f;
	}
	.navApp{
		font-size: 32rpx;
		font-weight: bold;
		color: #b37e93;
	}
	
	// 电影标题
	.filmType{
		border-bottom: 1px solid #e7e7e7;
	}
	.filmTypeItem{
		margin: 20rpx 25rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	.filmAdd{
		font-size: 30rpx;
		color: #999;
	}
	.filmAdd::after{
		content: "";
		width: 0;
		height: 0;
		border: 10rpx solid transparent;
		border-top: 10rpx solid #b0b0b0;
		position: relative;
		top: 14px;
		left: 6px;
	}
	.filmTypeMsg{
		// font-size: 34rpx;
		font-weight: bold;
		color: #666666;
	}
	.filmTypeMsgAfter{
		font-weight: bold;
		color: #000;
		font-size: 30rpx;
		border-bottom: 3px solid #e54847;
		padding-bottom: 8rpx;
	}
	
	
	
	// 最受好评电影
	.goodFilm{
		margin: 20rpx 25rpx;
	}
	.goodTitle{
		margin: 0rpx 0 20rpx 0;
	}
	.gootItem{
		display: flex;
	}
	.goodScorllView{

	}
	.gootItemMsg{
		margin-right:20rpx;
		position: relative;
	}
	.gootImage{
		width: 170rpx;
		height: 230rpx;
	}
	.goodFen{
		position: absolute;
		top: 190rpx;
		color: #faaf00;
		font-weight: bold;
		font-size: 24rpx;
		width: 170rpx;
		text-align: center;
	}
	.gootName{
		width: 170rpx;
		font-size: 26rpx;
		font-weight: bold;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	
	
	// 推荐电影
	.pushFilm{
		margin: 20rpx 25rpx;
	}
	.pushFileItem{
		display: flex;
		position: relative;
		border-bottom: 1px solid #e7e7e7;
		margin: 10rpx 0;
		padding: 20rpx 0;
	}
	.buyPushFilm{
		position: absolute;
		background-color: #f03d37;
		color: #fff;
		font-weight: bold;
		padding: 8rpx 20rpx;
		border-radius: 40rpx;
		right: 30rpx;
		top: 80rpx;
	}
	.pushD{
		// position: absolute;
		// right: 80rpx;
		border-radius: 5rpx;
		margin-left: 10rpx;
		width: 80rpx;
		height: 30rpx;
	}
	.pushFilmImage{
		width: 128rpx;
		height: 180rpx;
	}
	
	
	.pushFilmRight{
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		margin-left: 30rpx;
		width: 400rpx;
		font-size: 26rpx;
		color: #999;
	}
	.pushFilmName{
		font-weight: bold;
		font-size: 34rpx;
		color: #4d4d4d;
		margin-bottom: 10rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.pushFen{
		display: flex;
	}
	.pushFilmMsg{
		margin-left: 10rpx;
		color: #faaf00;
		font-weight: bold;
	}
	.pushActor{
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	
	// 娱乐热点
	.recreation{
		margin: 20rpx 25rpx;
	}
	.recreationTitle{
		margin: 20rpx 0 30rpx 0;
	}
	.recreationCentent{
		margin: 30rpx 20rpx 30rpx 0;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	
	
	// 影院
	.dropDown{
		border-bottom: 1px solid #e7e7e7;
	}
	.yingyuanItem{
		margin: 30rpx 25rpx;
		padding-bottom: 30rpx;
		border-bottom:1px solid #e7e7e7 ;
	}
	.yingyuanName{
		font-size: 32rpx;
	}
	.yingyuanPrice{
		margin-left: 20rpx;
		color: #f03d37;
		font-size: 36rpx;
	}
	.yingyuanY{
		margin-left: 5rpx;
		font-size: 24rpx;
		color: #f03d37;
	}
	.yingyuanAdd{
		margin: 15rpx 0;
		color: #999;
		font-size: 24rpx;
	}
	.yingyuanlan{
		font-size: 24rpx;
		border: 1px solid #589daf;
		border-radius: 5rpx;
		padding: 0 8rpx;
		color:#589daf ;
		margin-right: 10rpx;
	}
	.yingyuanhuang{
		font-size: 24rpx;
		border: 1px solid #ff9900;
		border-radius: 5rpx;
		padding: 0 8rpx;
		color:#ff9900 ;
		margin-right: 10rpx;
	}
	.yingyuanvip{
		margin-top: 15rpx;
		display: flex;
	}
	.yingyuanIcon{
		width: 30rpx;
		height: 28rpx;
		transform: translate(0rpx,2rpx);
	}
	.yingyuanyouhui{
		margin-left: 10rpx;
		font-size: 24rpx;
		color: #999;
	}
</style>
