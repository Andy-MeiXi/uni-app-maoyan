<template>
	<view>
		<view class="navbar">
			<u-navbar  
				title="中影华臣影城(石榴中心店)" 
				title-size="36"
				title-color="#fff" 
				title-width="500"
				:background="background"
				height="50"
				back-icon-color="#fff"
			>
				</u-icon>
			</u-navbar>
		</view>
		
		<view class="navCenter">
			<view class="navCenterflex">
				<image 
					class="navImage"
					src="../../static/image/maoyanLogo.png"
					mode="aspectFill">
				</image>
				<view class="navCenterflexRight">
					<view class="navFaxian">19.9元购票</view>
					<view class="navApp">打开App ></view>
				</view>
			</view>
		</view>
		
		<view class="dingweiBox">
			<view class="dwBoxLeft">
				<view class="dwName">中影华臣影城(石榴中心店)</view>
				<view class="dwAdd">丰台区榴乡路88号院石榴中心斯坦福广场B1层</view>
			</view>
			<image class="dingwei"
			src="../../static/image/dingwei.png" mode="aspectFill"></image>
		</view>
		
		<view class="bgColor">
			<image class="bgImage" mode="aspectFill" src="../../static/image/bj.png"></image>
		</view>
		
		<view class="filmName">
			<view class="filmNameMsg">
				<view class="filmMingzi">长津湖之水门桥</view>
				<view class="filmfen">9.6</view>
				<text class="fen">分</text>
			</view>
			<view class="filmActor">149分钟 | 剧情 | 吴京,易烊千玺,朱亚文</view>
		</view>
		
		<view class="filmTime">
			<view class="filmTimeItem">
				<view class="timeContentCheck">今天 5月25日</view>
				<view class="timeContent">周二 5月31日</view>
			</view>
		</view>
		
		<view class="movieh">
			<view class="movieBox">
				<view class="movie">
					<view class="movieTop">
						<view class="ksTime">07:05</view>
						<view class="yuyan">国语 2D</view>
						<view class="moviePrice">
							<view class="rmb">￥</view>
							<view class="rmbPrice">19.9</view>
						</view>
					</view>
					<view class="movieBottom">
						<view class="scTime">09:34散场</view>
						<view class="movieAdd">1号厅</view>
					</view>
				</view>
				<view class="movieRight">
					满座
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data(){
			return{
				background:{
					backgroundColor:'#e54847'
				},
			}
		},
		methods:{
			
		}
	}
</script>

<style lang="scss" scoped>
	.navCenter{
		border-bottom: 1px solid #e7e7e7;
	}
	.navCenterflex{
		margin: 20rpx 25rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.navImage{
		width: 180rpx;
		height: 80rpx;
	}
	.navCenterflexRight{
		display: flex;
		align-items: center;
	}
	.navFaxian{
		margin-right: 20rpx;
		font-size: 28rpx;
		font-weight: bold;
		color: #66667f;
	}
	.navApp{
		font-size: 32rpx;
		font-weight: bold;
		color: #b37e93;
	}
	
	// 定位
	.dingweiBox{
		margin: 0 25rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 40rpx;
	}
	.dwBoxLeft{
		flex: 4;
	}
	.dingwei{
		// flex: 1;
		margin-right: 40rpx;
		border-left: 1px solid #e7e7e7;
		padding-left: 40rpx;
		width: 38rpx;
		height: 44rpx;
	}
	.dwName{
		font-size: 34rpx;
		margin: 15rpx 0;
	}
	.dwAdd{
		font-size: 26rpx;
		color: #999;
	}
	
	.bgColor{
		width: 750rpx;
		height: 270rpx;
	}
	.bgImage{
		width: 100%;
		height: 100%;
	}
	.filmName{
		margin: 30rpx 0;
		text-align: center;
		padding-bottom: 20rpx;
		border-bottom: 1px solid #e7e7e7;
	}
	.filmNameMsg{
		display: flex;
		justify-content: center;
		align-items: center;
		margin-bottom: 10rpx;
	}
	.filmMingzi{
		font-size: 34rpx;
	}
	.filmfen{
		margin-left: 10rpx;
		color: #ffb400;
		font-size: 34rpx;
		font-weight: bold;
	}
	.fen{
		font-weight: none;
		font-size: 32rpx;
		color: #ffb400;
	}
	.filmActor{
		font-size: 26rpx;
		color: #999;
	}
	.filmTime{
		margin: 20rpx 0;
		// padding-bottom: 20rpx;
		border-bottom: 1px solid #e7e7e7;
	}
	.filmTimeItem{
		display: flex;
	}
	.timeContent{
		margin: 0 30rpx;
		font-size: 28rpx;
		color: #999;
	}
	.timeContentCheck{
		margin: 0 30rpx;
		font-size: 28rpx;
		color: #e54847;
		padding-bottom: 20rpx;
		border-bottom: 4rpx solid #e54847;
	}
	
	.movieh{
		border-bottom: 1px solid #e7e7e7;
	}
	.movieBox{
		margin: 30rpx 25rpx;
		align-items: center;
		display: flex;
		justify-content: space-between;
	}
	
	.movie{
		// display: flex;
	}
	.movieTop{
		display: flex;
		align-items: center;
	}
	.ksTime{
		font-size: 42rpx;
	}
	.yuyan{
		margin-left: 44rpx;
	}
	.moviePrice{
		display: flex;
	}
	.movieBottom{
		align-items: center;
		display: flex;
		color: #999;
		font-size: 24rpx;
	}
	.scTime{
		
	}
	.movieAdd{
		margin-left: 40rpx;
	}
	.moviePrice{
		margin-left: 80rpx;
		color: #e54847;
	}
	.rmb{
		font-size: 24rpx;
		transform: translate(0rpx,10rpx);
	}
	.rmbPrice{
		font-size: 34rpx;
	}
	.movieRight{
		border: 1px solid #999;
		border-radius: 30rpx;
		padding: 8rpx 20rpx;
		font-size: 24rpx;
		color: #999;
	}
</style>
