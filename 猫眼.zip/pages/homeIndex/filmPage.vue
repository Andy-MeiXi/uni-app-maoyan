<template>
	<view class="filmPage">
		<!-- 头部导航栏 -->
		<view class="navCenter">
			<view class="navCenterflex">
				<image 
					class="navImage"
					src="../../static/image/maoyanLogo.png"
					mode="aspectFill">
				</image>
				<view class="navCenterflexRight">
					<view class="navFaxian">领取50元电影票</view>
					<view class="navApp">打开App ></view>
				</view>
			</view>
		</view>
		
		<!-- 影视详情上半页 -->
		<view class="film">
			<!-- 路径信息 -->
			<view class="path">
				<view class="pathFont">猫眼电影 > 神奇动物:邓布利多之谜</view>
			</view>
			<!-- 电影简单介绍 -->
			<view class="filmJS">
				<view class="filmJSImageBox">
					<image 
						class="filmJSImage"
						src="../../static/image/film1.jpg" 
						mode="aspectFill"
					></image>
				</view>
				<view class="filmJSRight">
					<view class="filmJSName">神奇动物:邓布利多之谜</view>
					<view class="filmEmsg">Fantasitic Beasts:The Secrets of Dumble Fantasitic Beasts:The Secrets of Dumble</view>
					<view class="bianju filmType">奇幻/冒险/剧情</view>
					<view class="bianju">埃迪·雷德梅恩、裘德·洛、麦斯·米科尔森</view>
					<view class="bianju">2022-04-08中国大陆上映/143分钟</view>
					<view class="filmJSRightBottom">
						<view class="filmJSRightBottomLeft">
							<u-icon class="filmIcon" name="heart" size="30"></u-icon>
							<view class="filmBtn">想看</view>
						</view>
						<view class="filmJSRightBottomRight">
							<u-icon  class="filmIcon" name="star" size="30"></u-icon>
							<view class="filmBtn">看过</view>
						</view>
					</view>
				</view>
			</view>
			
			<!-- 电影评分页面 -->
			<view class="pingFen">
				<view class="pingFenTop">
					<view class="pingFenTopRight">
						<image 
							class="pingFenImage"
							src="../../static/image/maologo.png"
							mode="aspectFill"></image>
						<view class="pingFenMao">猫眼购票评分</view>
					</view>
					<view>
						347,734人想看
					</view>
					<view>
						4,847,483人看过>
					</view>
				</view>
				<view class="pingFenBottom">
					<view class="pingFenBottomLeft">
						<view class="pingFenNum">7.9</view>
						<view class="pingFenCount">48,778 人评</view>
					</view>
					<view style="display: flex;flex-direction: column;">
						<!-- 一 -->
						<view class="pingFenBottomCentent">
							<view class="pingFenSumXing" >
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
							</view>
							<view class="bar">
								<view class="pingFenLine" style="width: 60.3%;"></view>
							</view>
						</view>
						<!-- 二 -->
						<view class="pingFenBottomCentent">
							<view class="pingFenSumXing" >
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
							</view>
							<view class="bar">
								<view class="pingFenLine" style="width: 30.3%;"></view>
							</view>
						</view>
						<!-- 三 -->
						<view class="pingFenBottomCentent">
							<view class="pingFenSumXing" >
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
							</view>
							<view class="bar">
								<view class="pingFenLine" style="width: 25.3%;"></view>
							</view>
						</view>
						<!-- 四 -->
						<view class="pingFenBottomCentent">
							<view class="pingFenSumXing" >
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
							</view>
							<view class="bar">
								<view class="pingFenLine" style="width: 10.3%;"></view>
							</view>
						</view>
						<!-- 五 -->
						<view class="pingFenBottomCentent">
							<view class="pingFenSumXing" >
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing.png"></image>
								<image
									class="pingFenXing"
									mode="aspectFill" 
									src="../../static/image/xing2.png"></image>
							</view>
							<view class="bar">
								<view class="pingFenLine" style="width: 24.3%;"></view>
							</view>
						</view>
		
		
					</view>
					<view class="pingFenBottomRight">
						<view class="pingFenBottomRightLeft">
							<view>TOP</view>
							<view>1</view>
						</view>
						<view class="pingFenBottomRightRight">
							<view>2022年4月</view>
							<view>中国大陆票房榜</view>
						</view>
					</view>
				</view>
			</view>
			
			<!-- 介绍 -->
			<view class="actorJianjie">
				<view class="actorTop">
					<view>简介</view>
					<view class="actorTopRight" v-if="!isShow" @click="clickBtn">
							<view>展开</view>
							<u-icon class="actorIcon" name="arrow-down" size="24" color="#999"></u-icon>
					</view>
					<view class="actorTopRight" v-else @click="clickBtn">
							<view>收回</view>
							<u-icon class="actorIcon" name="arrow-up" size="24" color="#999"></u-icon>
					</view>
				</view>
				<view :class=" !isShow ? 'actorContent':'actorContentShow'">
					阿不思·邓布利多教授（裘德·洛 饰）意识到强大的黑巫师盖勒特·格林德沃（麦斯·米科尔森 饰）正试图夺取魔法世界的控制权。邓布利多了解仅凭他一人之力，将无法阻止格林德沃，于是他委托魔法动物学家纽特·斯卡曼德（埃迪·雷德梅恩 饰）带领一支精良的团队——成员包括男巫、女巫及一位勇敢的麻瓜面包师，来共同执行这项危险任务。一路上他们会遇到各式各样的神奇动物，既有老朋友，也有前所未见的神秘生物；同时他们也随时会与格林德沃不断壮大的追随者发生冲突。这次行动的风险是如此之高……邓布利多还能袖手旁观多久？
				</view>
			</view>
			
			
			<!-- 演职人员 -->
			<view class="goodFilm">
				<view class="actorTop">
					<view>演职人员</view>
					<view class="actorTopRight">
							<view>全部</view>
							<u-icon class="yzIcon" name="arrow-right" size="24" color="#999"></u-icon>
					</view>
				</view>
				<scroll-view scroll-x="true" class="goodScorllView">
					<view class="gootItem">
						<view class="gootItemMsg"
							v-for="(item,index) in gootfilmlist"
							:key="item.id"
						>
							<image class="gootImage"
							 :src="item.image"></image>
							 <view class="goodFen">{{item.score}}</view>
							<view class="gootName">{{item.filmName}}</view>
						</view>
					</view>
				</scroll-view>
			</view>
			<!-- 视频推荐 -->
			<view class="goodFilm">
				<view class="actorTop">
					<view>视频推荐</view>
					<view class="actorTopRight">
							<view>全部</view>
							<u-icon class="yzIcon" name="arrow-right" size="24" color="#999"></u-icon>
					</view>
				</view>
				<scroll-view scroll-x="true" class="goodScorllView">
					<view class="gootItem">
						<view class="gootItemMsg"
							v-for="(item,index) in splist"
							:key="item.id"
						>
							<image class="spImage"
							 :src="item.image"></image>
						</view>
					</view>
				</scroll-view>
			</view>
			<!-- 剧照 -->
			<view class="goodFilm">
				<view class="actorTop">
					<view>剧照</view>
					<view class="actorTopRight">
							<view>全部{{jzlist.length}}张</view>
							<u-icon class="yzIcon" name="arrow-right" size="24" color="#999"></u-icon>
					</view>
				</view>
				<scroll-view scroll-x="true" class="goodScorllView">
					<view class="gootItem">
						<view class="gootItemMsg"
							v-for="(item,index) in jzlist"
							:key="item.id"
						>
							<image class="spImage"
							 :src="item.image"></image>
						</view>
					</view>
				</scroll-view>
			</view>
		</view>
		
		
		<!-- 影视详情下半页 -->
		<view class="filmHalf">
			<view class="piaofang">
				<view class="actorTop">
					<view>票房</view>
					<view class="actorTopRight">
							<view style="color: #999;">票房详情</view>
							<u-icon class="pfIcon" name="arrow-right" size="24" color="#999"></u-icon>
					</view>
				</view>
				<view class="boxOffice">
					<view>
						<view class="boxOfficeNum">6</view>
						<view class="boxOfficeTitle">昨日排名</view>
					</view>
					<view>
						<view class="boxOfficeNum">6,213</view>
						<view class="boxOfficeTitle">首周票房(万)</view>
					</view>
					<view>
						<view class="boxOfficeNum">17,630</view>
						<view class="boxOfficeTitle">累计票房(万)</view>
					</view>
				</view>
			</view>
		</view>
		
		<view class="kongDiv">
		</view>
		
		<view class="zixun">
			<view class="zixunTop">
				<view>相关快讯</view>
				<view class="zixunTopRight">
					<view class="zixunTopRightfont">全部</view>
					<u-icon class="zixunIcon" name="arrow-right" size="24" color="#999"></u-icon>
				</view>
			</view>
			<view class="zixunItem" 
				v-for="(item,index) in zixunlist"
				:key="item.id"
				>
				<view class="zixunTop">
					<view class="zxLeft">{{item.title}}</view>
					<image
						class="zixunImage"
						mode="aspectFill"
						:src="item.image"></image>
				</view>
				<view class="zixunBottom">
					<view class="zxbottom">{{item.filmNmae}}</view>
					<view class="zxBottomRight">
						<u-icon class="zxIcon" name="eye" size="24" color="#999"></u-icon>
						<view class="zxText">{{item.see}}</view>
						<u-icon class="zxIcon" name="chat" size="24" color="#999"></u-icon>
						<view class="zxText">{{item.comment}}</view>
					</view>
				</view>
			</view>
		</view>
		
		
		<view class="footer">
			<view class="footerTitle">影视行业信息<a href="#"> 《免责声明》 </a>| 违法和不良信息举报电话: 4006018
</view>
			<image
				class="footerImage"
				src="../../static/image/hblogo.png"
				mode="aspectFill">
			</image>
		</view>
		
	</view>
</template>

<script>
	export default {
		data(){
			return{
				isShow:false,
				gootfilmlist:[
					{
						id:1,
						image:'/static/image/dy1.png',
						score:'大卫·叶茨',
						filmName:'导演'
					},{
						id:2,
						image:'/static/image/dy2.png',
						score:'埃迪·雷德梅恩',
						filmName:'饰:Newt Score'
					},{
						id:3,
						image:'/static/image/dy3.png',
						score:'艾莉森·苏朵儿',
						filmName:'饰:Queenie Goltina'
					},{
						id:4,
						image:'/static/image/dy4.png',
						score:'裘德·洛',
						filmName:'饰:Albus Dultina'
					},{
						id:5,
						image:'/static/image/dy5.png',
						score:'凯瑟琳·沃特森',
						filmName:'饰:Newt Score'
					},{
						id:6,
						image:'/static/image/dy6.png',
						score:'麦斯·米科尔森',
						filmName:'饰:GrindelW Golina'
					},{
						id:7,
						image:'/static/image/dy7.png',
						score:'埃兹·拉米勒',
						filmName:'饰:Credenc Golina'
					}
				],
				splist:[
					{
						id:1,
						image:'/static/image/sp1.jpg'
					},{
						id:2,
						image:'/static/image/sp2.jpg'
					},{
						id:3,
						image:'/static/image/sp3.jpg'
					},{
						id:4,
						image:'/static/image/sp4.jpg'
					},
				],
				jzlist:[
					{
						id:1,
						image:'/static/image/jz1.jpg'
					},{
						id:2,
						image:'/static/image/jz2.jpg'
					},{
						id:3,
						image:'/static/image/jz3.jpg'
					},{
						id:4,
						image:'/static/image/jz4.jpg'
					},{
						id:5,
						image:'/static/image/jz5.jpg'
					},{
						id:6,
						image:'/static/image/jz6.jpg'
					},{
						id:7,
						image:'/static/image/jz7.jpg'
					},
				],
				zixunlist:[
					{
						id:1,
						title:'《神奇动物:邓布利多之谜》票房破亿魔法世界重返银幕掀观影热潮',
						image:'/static/image/zx1.jpg',
						filmNmae:'猫眼电影 04-22',
						see:'6639',
						comment:'5'
					},{
						id:2,
						title:'《神奇动物:邓布利多之谜》上映延期至6月7日8',
						image:'/static/image/zx2.jpg',
						filmNmae:'猫眼电影 04-22',
						see:'4891',
						comment:'0'
					},
				]
			}
		},
		methods:{
			clickBtn(){
				this.isShow = !this.isShow
			}
		}
	}
</script>

<style lang="scss" scoped>
	// page{
	// 	background-color: #19402c;
	// }
	// .filmPage{
	// 	background-color: #19402c;
	// 	height: 150vh;
	// }
	.kongDiv{
		width: 750rpx;
		height:20rpx;
		background-color: #f2f2f2;
	}
	.navCenter{
		// border-bottom: 1px solid #e7e7e7;
		background-color: #ffffff;
		position: relative;
		top: -20rpx;
		width: 750rpx;
		height: 100rpx;
		line-height: 100rpx;
	}
	.navCenterflex{
		margin: 20rpx 25rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.navImage{
		width: 180rpx;
		height: 80rpx;
	}
	.navCenterflexRight{
		display: flex;
		align-items: center;
	}
	.navFaxian{
		margin-right: 20rpx;
		font-size: 28rpx;
		font-weight: bold;
		color: #66667f;
	}
	.navApp{
		font-size: 32rpx;
		font-weight: bold;
		color: #b37e93;
	}
	.film{
		padding: 20rpx 25rpx;
		background-color: #19402c;
	}
	.pathFont{
		color: #fff;
		font-size: 24rpx;
	}
	
	// 电影简单介绍
	.filmJS{
		margin: 30rpx 0;
		display: flex;
		justify-content: space-between;
		color: #fff;
	}
	.filmJSImageBox{
		width: 200rpx;
		height: 276rpx;
	}
	.filmJSImage{
		width: 100%;
		height: 100%;
	}
	.filmJSRight{
		margin-left: 30rpx;
		flex: 2;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		font-size: 24rpx;
		color: rgba(255,255,255,.6);
	}
	.filmJSName{
		font-weight: bold;
		font-size:40rpx;
		color:#fff;
		margin-bottom: 20rpx;
	}
	.filmEmsg{
		overflow: hidden;
		display: -webkit-box;
		-webkit-box-orient:vertical;
		-webkit-line-clamp:1;
	}
	.bianju{
		margin: 5rpx 0;
	}
	.filmType::after{
		content: "2D IMAX";
		background-color: rgba(255,255,255,.2);
		color: rgba(255,255,255,.4);
		margin-left: 10rpx;
		padding: 0 5rpx;
	}
	.filmJSRightBottom{
		display: flex;
		justify-content: space-between;
	}
	.filmJSRightBottomLeft{
		display: flex;
		color: #fff;
		background-color: rgba(255,255,255,.4);
		padding: 10rpx 70rpx;
		border-radius: 10rpx;
	}
	.filmJSRightBottomRight{
		display: flex;
		color: #fff;
		background-color: rgba(255,255,255,.4);
		padding: 10rpx 70rpx;
		border-radius: 10rpx;
	}
	.filmIcon{
		transform: translate(-10rpx,0rpx);
	}
	
	// 电影评分
	.pingFen{
		padding: 20rpx 0;
		background-color: #143424;
		border-radius: 20rpx;
		height: 204rpx;
	}
	.pingFenTop{
		display: flex;
		justify-content: space-around;
		align-items: center;
		color: rgba(255,255,255,.6);
		font-size: 24rpx;
		
	}
	.pingFenTopRight{
		display: flex;
	}
	.pingFenImage{
		width: 32rpx;
		height: 32rpx;
	}
	.pingFenMao{
		color: #fff;
		margin-left: 10rpx;
	}
	.pingFenBottom{
		margin: 10rpx 0;
		display: flex;
		justify-content: space-between;
		
	}
	.pingFenBottomLeft{
		margin-left: 40rpx;
	}
	.pingFenNum{
		margin-left: 50rpx;
		font-weight: bold;
		font-size:52rpx;
		color: #d2a800;
	}
	.pingFenCount{
		font-size: 24rpx;
		color: rgba(255,255,255,.4);
	}
	.pingFenBottomCentent{
		margin-left: 10rpx;
		height: 20rpx;
		display: flex;
		align-items: center;
	}
	.pingFenXing{
		width: 10rpx;
		height: 10rpx;
		margin: 0 2rpx;
	}
	.bar{
		width: 3rem;
		height: 0.18rem;
		background-color: hsla(0,0%,100%,.06);
		border-radius: 0.02rem;
		margin-left: 0.08rem;
		transform: translate(5rpx,8rpx);
	}
	.pingFenLine{
		// transform: translate(5rpx,8rpx);
		height: 100%;
		width: 0;
		background: hsla(0,0%,100%,.3);
		border-radius: 0.02rem;
		transition: width 1.5s;
	}
	.pingFenBottomRight{
		padding: 8rpx 8rpx;
		margin-right: 25rpx;
		display: flex;
		justify-content: space-between;
		color: rgba(255,255,255,.4);
		border: 1px solid #b6b65a;
		border-radius: 20rpx;
		transform: translate(0rpx,10rpx);
	}
	.pingFenBottomRightLeft{
		background-color: #424f30;
		border-radius: 10rpx;
		font-size: 24rpx;
		text-align: center;
		line-height: 40rpx;
		padding: 0 8rpx;
	}
	.pingFenBottomRightRight{
		font-size: 24rpx;
		line-height: 40rpx;
		margin-left: 10rpx;
		color: #fff4bd;
	}
	.pingFenBottomRightRight view:nth-child(1){
		color: rgba(255,244,189,.6);
	}
	
	// 简介
	.actorJianjie{
		color: #fff;
	}
	.actorTop{
		margin: 30rpx 0;
		display: flex;
		justify-content: space-between;
	}
	.actorTopRight{
		display: flex;
		align-items: center;
	}
	.actorTopRight view:nth-child(1){
		font-size: 24rpx;
		margin-right: 10rpx;
		color: rgba(255,255,255,.6);
	}
	.actorContent{
		line-height: 44rpx;
		overflow: hidden;
		display: -webkit-box;
		-webkit-box-orient:vertical;
		-webkit-line-clamp:3;
	}
	.actorContentShow{
		line-height:44rpx;
	}
	
	// 演职人员
	.goodFilm{
		margin: 40rpx 0;
		// margin: 20rpx 25rpx;
		color: #fff;
	}
	.goodTitle{
		margin: 0rpx 0 20rpx 0;
	}
	.gootItem{
		display: flex;
	}
	.goodScorllView{
	
	}
	.gootItemMsg{
		margin-right:20rpx;
		position: relative;
	}
	.gootImage{
		width: 160rpx;
		height: 224rpx;
	}
	.goodFen{
		// position: absolute;
		// top: 190rpx;
		// color: #faaf00;
		// font-weight: bold;
		// font-size: 24rpx;
		// width: 170rpx;
		text-align: center;
		font-size: 24rpx;
	}
	.gootName{
		color: rgba(255,255,255,.4);
		width: 170rpx;
		font-size: 24rpx;
		// font-weight: bold;
		text-align: center;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	.yzIcon{
		transform: translate(0,3rpx);
	}
	.spImage{
		border-radius: 20rpx;
		width: 280rpx;
		height: 196rpx;
	}
	
	// 下部
	.filmHalf{
		margin: 30rpx 25rpx;
	}
	.piaofang{
		// margin: 30rpx 0;
		padding: 0rpx 0rpx 30rpx 0; 
	}
	.pfIcon{
		transform: translate(0rpx,3rpx);
	}
	.boxOffice{
		display: flex;
		justify-content: space-around;
	}
	.boxOfficeNum{
		color: #f00;
		font-size: 34rpx;
		text-align: center;
		margin: 10rpx 0;
	}
	.boxOfficeTitle{
		color: #999;
		font-size: 24rpx;
	}
	// 相关快讯
	.zixun{
		margin: 30rpx 25rpx;
	}
	.zixunTop{
		display: flex;
		justify-content: space-between;
	}
	.zixunTopRight{
		display: flex;
		align-items: center;
	}
	.zixunTopRightfont{
		color: #999;
	}
	.zixunIcon{
		margin-left: 10rpx;
		transform: translate(0rpx,2rpx);
	}
	.zixunItem{
		margin: 30rpx 0;
	}
	.zixunTop{
		display: flex;
	}
	.zxLeft{
		flex: 2;
		font-size: 34rpx;
		padding: 0 10rpx;
	}
	.zixunImage{
		width: 220rpx;
		height: 156rpx;
	}
	.zixunBottom{
		margin-top: 10rpx;
		font-size: 24rpx;
		color: #999;
		display: flex;
		justify-content: space-between;
	}
	.zxbottom{
		flex: 2;
	}
	.zxBottomRight{
		flex: 1;
		display: flex;
		justify-content: space-between;
	}
	.zxIcon{
		margin-left: 12rpx;
	}
	.zxText{
		transform: translate(-26rpx,-2rpx);
	}
	
	//	底部
	.footer{
		position: relative;
		background-color: #f4f4f4;
		padding: 30rpx 25rpx;
		height: 200rpx;
	}
	.footer a{
		text-decoration: none;
		color: #4e759e;
	}
	.footerTitle{
		color: #999;
		font-size: 24rpx;
		line-height: 110rpx;
	}
	.footerImage{
		width: 156rpx;
		height: 44rpx;
		position: absolute;
		top:70%;
		left: 50%;
		transform: translate(-50%,-50%);
	}
	
	
	
</style>
